
Changelog
=========

0.0.0 (2020-11-27)
------------------

* First release on PyPI.
