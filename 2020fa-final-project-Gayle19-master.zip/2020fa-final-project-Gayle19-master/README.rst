========
Overview
========

.. start-badges

.. list-table::
    :stub-columns: 1

    * - tests
      - | |travis|
        |
        | |codeclimate|
        |
        | |codeclimate_cov|
   

.. |travis| image:: https://travis-ci.com/Gayle19/2020fa-final-project-Gayle19.svg?token=YFVNjWMfbzHWZG26kJpy&branch=master
    :target: https://travis-ci.com/Gayle19/2020fa-final-project-Gayle19

.. |codeclimate|  image:: https://api.codeclimate.com/v1/badges/7e39f3d26760510b0a93/maintainability
   :target: https://codeclimate.com/repos/5fda806aa3137a01a2006bcc/maintainability
   :alt: Maintainability


.. |codeclimate_cov| image:: https://api.codeclimate.com/v1/badges/7e39f3d26760510b0a93/test_coverage
   :target: https://codeclimate.com/repos/5fda806aa3137a01a2006bcc/test_coverage
   :alt: Test Coverage




.. end-badges

"A machine learning utilities package"

Installation
============

::

    pip install machine-learning-utils

You can also install the in-development version with::

    pip install https://github.com/Gayle19/2020fa-machinelearning-utils-Gayle19/archive/master.zip


Documentation
=============


To use the project:

.. code-block:: python

    import machine_learning_utils
    machine_learning_utils.longest()


Development
===========

To run all the tests run::

    tox

Note, to combine the coverage data from all the tox environments run:

.. list-table::
    :widths: 10 90
    :stub-columns: 1

    - - Windows
      - ::

            set PYTEST_ADDOPTS=--cov-append
            tox

    - - Other
      - ::

            PYTEST_ADDOPTS=--cov-append tox
